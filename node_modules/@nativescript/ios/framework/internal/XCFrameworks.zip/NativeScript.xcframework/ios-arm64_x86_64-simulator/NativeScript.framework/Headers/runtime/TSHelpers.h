#ifndef TSHelpers_h
#define TSHelpers_h

#include "Common.h"

namespace tns {

class TSHelpers {
public:
    static void Init(v8::Local<v8::Context> context);
};

}

#endif /* TSHelpers_h */
